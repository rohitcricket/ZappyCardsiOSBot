//
//  AppDelegate.h
//  DemoApp
//
//  Created by Michael Spensieri on 12/10/13.
//  Copyright (c) 2015 Smooch Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString* const KnowledgeBaseURL;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
