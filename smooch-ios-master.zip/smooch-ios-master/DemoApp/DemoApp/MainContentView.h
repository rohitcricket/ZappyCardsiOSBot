//
//  MainContentView.h
//  DemoApp
//
//  Created by Michael Spensieri on 12/19/13.
//  Copyright (c) 2015 Smooch Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainContentView : UIView

@property UINavigationBar* navBar;
@property UIButton* button;

@end
